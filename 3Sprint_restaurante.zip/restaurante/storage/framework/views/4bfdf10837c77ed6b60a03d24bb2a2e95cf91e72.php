<?php $__env->startSection('content'); ?>
<div class="bg-light p-5 rounded" style="margin:10px;">

    <div  style="text-align: right">
        <a  class="btn btn-outline-danger" href="/index">Logout</a>
    </div>
    <form method="POST" <?php echo e(route('messages.createc')); ?>>
        <?php echo csrf_field(); ?>
        <br>
        <h1 class="h3 mb-3 fw-normal">Mensagens</h1>
        <form style="text-align: center; align-right;" >
        <table class="table table-striped">
            <tr>
                <th class="col-2" style="border: 2px solid #000000">Nome: </th>
                <th class="col-10" style="border: 2px solid #000000">Mensagem: </th>
            </tr>

            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style=>
                    <td style="border: 1px solid #000000"><?php echo e($mes->clienteNome->nome); ?></td>
                    <td style="border: 1px solid #000000"><?php echo e($mes->mensagem); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <br>
        <div>
            <input type="button" class="btn btn-primary" value="Voltar" onClick="history.go(-1)">
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master-no-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Joao Aragao\OneDrive - Maieutica\2ºAno\2º Semestre\Engenharia de Software\Engenharia-Software\restaurante\resources\views/messages-func/show.blade.php ENDPATH**/ ?>