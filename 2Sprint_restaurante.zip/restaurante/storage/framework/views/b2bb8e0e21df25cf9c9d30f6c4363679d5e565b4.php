<?php $__env->startSection('content'); ?>
<div class="bg-light p-5 rounded" style="margin:10px;">
    <?php if(auth()->guard()->check()): ?>
        <h1>Dashboard</h1>
    <?php endif; ?>
    <?php if(auth()->guard()->guest()): ?>
        <h1>Homepage</h1>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\EngenhariaSoftware\restaurante\resources\views/home/index.blade.php ENDPATH**/ ?>